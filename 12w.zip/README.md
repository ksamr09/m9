10 Akun BotProtect + 1 Akun Bot Satpam

===Bot Kris===

- Versi Kris :
- http://line.me/ti/p/GkwfNjoPDH

==================================

Fungsinya:
- untuk protek pastinya
- Admin ke kick akan di undang otomatis
- bot lainya ke kick akan di undang lagi
- kalau admin nyuruh nendang member, bot satpam akan masuk lewat kode qr dan terus mengkick target tsb dan left lagi
- Akun utama ke kick akan di undang otomatis oleh bot lainnya
- kalau ada yang ngetag bot akan di kick
- dan banyak fitur2 lainnya yang menarik
- Akun kita sendiri tidak mesti di room tersebut/jadi akun kita tidak banyak room
- join in my team ✰ tɛǟʍ ċʏɮɛʀ-ǟʀʍʏ ɮօt ✰

kode-kode penginstalan bot bisa langsung tanyakan di link kontak di atas

=======================================================================
